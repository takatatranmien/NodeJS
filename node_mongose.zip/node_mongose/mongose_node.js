﻿var mongoose = require('mongoose');

var db = mongoose.connection;

db.on('error', console.error);
db.once('open', function () {
    // tạo  schemas and models ở đây.
    var smartjobSchema = new mongoose.Schema({
        title: { type: String }, skill: String, phone: Number, hasPublic: Boolean
    });
    // Tạo ra  a 'Smartjob' model using the movieSchema as the structure.
    // Mongoose cũng sẽ tạo ra  1  collection smartjobs called 'Smarjob' cho documentmowis được tạo này.
    var Smartjob = mongoose.model('Smartjob', smartjobSchema);
    var thor = new Smartjob(
	{
	    title: 'nguyen van tuan', skill: 'ios', phone: '0987844217'  // ở đây sử dụng string thay vì Number thì Mongoose sẽ tự convert sang Number cho bạn
        , hasPublic: true
    });
    thor.save(function (err, thor) {
        if (err) return console.error(err);
        console.dir(thor);
    });
});

mongoose.connect('mongodb://localhost/test');
