var mongoose = require('mongoose');
var db = mongoose.connection;

db.on('error', console.error);
db.once('open', function () {
    // tạo  schemas and models ở đây.
    var smartjobSchema = new mongoose.Schema({
        title: { type: String }, skill: String, phone: Number, hasPublic: Boolean
    });
    // tao model smarjob tương ứng với schema đã khai báo bên trên
    var Smartjob = mongoose.model('Smartjob', smartjobSchema);

	Smartjob.remove({ title: 'hoang van tu' }, function (err) {
	if (err) return handleError(err);
	// removed!
	console.log("xoa thanh cong");
	});
});

mongoose.connect('mongodb://localhost/test');

